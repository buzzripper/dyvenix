﻿namespace Dyvenix.App1.Server.Config
{
	public static class ConfigConst
	{
		// Application
		public const string AppName = "app1.server";
		public const string AppDisplayName = "App1 Server";



		//// Logging
		//public const string LogsFolder = "Logs";
		//public const string LogFilename = "app1.server.log";

		//// Status response
		//public const string Status_Ok = "ok";
		//public const string Status_Error = "error";
	}
}
