﻿namespace Dyvenix.App1.Server.Models;

public static class AppConst
{
	public const string AppId = "App1";
}
