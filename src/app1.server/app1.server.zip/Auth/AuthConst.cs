﻿namespace Dyvenix.App1.Server.Auth;

public static class AuthConst
{
	public const string Scope_Api1_Read = "api.read";
	public const string Scope_Api1_Write = "api.write";
}
